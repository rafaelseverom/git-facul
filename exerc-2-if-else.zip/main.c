/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a = 24 ;
int b = 0;
if(a == 10) {
    printf("a é igual a %d \n",a);
}else{
    printf("%d é diferente de 10 \n",a);
}

if( b != 0){
    printf("%d e diferente de zero \n",b);
}else{
    printf("b e igual a %d \n",b);
}


return 0;
    
}



